# About the Challange

This challange was made to teach people the essential linux commands that i think everyone should know 

you can read the blog it will have all the commands you will need with a simple explanation
